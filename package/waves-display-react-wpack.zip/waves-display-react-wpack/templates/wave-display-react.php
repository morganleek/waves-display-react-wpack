<?php /* Template name: Wave Display - React */ ?>

	<?php get_header(); ?>
		<div id="root"></div>	
	<?php get_footer(); ?>

	</body>
</html>
