<?php 
	// Admin Options
	require_once( WAD__PLUGIN_DIR . 'includes/admin-options.php' );